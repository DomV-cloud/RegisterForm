from flask import Flask, jsonify
from flask_marshmallow import Marshmallow
from flask_sqlalchemy import SQLAlchemy
from webargs import fields, validate, ValidationError
from webargs.flaskparser import use_args

app = Flask(__name__)
# Database configuration
app.config.from_mapping(
    SQLALCHEMY_DATABASE_URI='sqlite:///demo.db'
)
db = SQLAlchemy(app)
ma = Marshmallow(app)


# Database model with all required columns
class Student(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String, nullable=False, unique=True)
    partner = db.Column(db.String, nullable=False)
    can_swim = db.Column(db.Boolean, nullable=False, default=False)


# Validation of the uniqueness of the name.
def validate_uniqueness(val):
    # If a student with that name already exists, throw an error.
    if Student.query.filter_by(name=val).first():
        raise ValidationError('Name already exists.')


# Scheme for serialization and validation
class StudentSchema(ma.SQLAlchemyAutoSchema):
    name = ma.String(required=True,
                     validate=[
                         validate.Length(min=2, max=8),
                         validate.Regexp(r'^[A-Za-z]+[0-9]*$'),
                         validate_uniqueness
                     ]
                     )
    partner = ma.String(required=True,
                        validate=[
                            validate.Length(min=2, max=8),
                            validate.Regexp(r'^[A-Za-z]+[0-9]*$')
                        ]
                        )
    can_swim = ma.Boolean(required=True)

    class Meta:
        model = Student
        load_instance = True


# Creation of the database.
# This can also be done via the flask shell.
with app.app_context():
    db.drop_all()
    db.create_all()


# Deliver the VueJS application as a static page.
@app.route('/')
def index():
    return app.send_static_file('registration.html')


# Creation of a new database entry
@app.post('/students/new')
@use_args(StudentSchema(), location='json')
def students_create(student):
    # Save the data to the database.
    db.session.add(student)
    db.session.commit()
    # Convert the data to JSON.
    student_schema = StudentSchema()
    student_data = student_schema.dump(student)
    return jsonify(student_data)


# Query and delivery of all existing database entries.
@app.route('/students')
def students():
    # Query all students from the database.
    students = Student.query.all()
    # Convert the data to JSON.
    student_schema = StudentSchema(many=True)
    student_data = student_schema.dump(students)
    return jsonify(student_data)


# Error handler for failed validation.
@app.errorhandler(422)
@app.errorhandler(400)
def handle_error(err):
    headers = err.data.get("headers", None)
    messages = err.data.get("messages", ["Invalid request."])
    if headers:
        return jsonify({"errors": messages}), err.code, headers
    else:
        return jsonify({"errors": messages}), err.code
